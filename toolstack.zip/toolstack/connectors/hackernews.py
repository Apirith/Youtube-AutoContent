"""
connectors/hackernews.py

Pulls "Show HN" posts via Algolia's free HN API. No auth required.
Targets: Show HN posts, under 72 hours old, < 80 points, AI keywords.

Algolia HN docs: https://hn.algolia.com/api
"""
import httpx
from datetime import datetime, timedelta, timezone
from typing import Optional
from tenacity import retry, stop_after_attempt, wait_exponential

from toolstack.models import ToolCandidate
from toolstack.config import FRESHNESS_DAYS

BASE_URL = "https://hn.algolia.com/api/v1/search"

AI_KEYWORDS = [
    "ai", "llm", "gpt", "claude", "gemini", "agent", "automation",
    "ml", "voice", "chatbot", "copilot", "generative", "openai",
    "model", "inference", "embedding", "rag", "multimodal",
]

MAX_POINTS_FOR_OBSCURE = 150


def _extract_url(hit: dict) -> str:
    return hit.get("url") or f"https://news.ycombinator.com/item?id={hit['objectID']}"


def _parse_date(ts: Optional[int]) -> Optional[datetime]:
    if ts is None:
        return None
    return datetime.fromtimestamp(ts, tz=timezone.utc).replace(tzinfo=None)


def _is_ai_related(title: str, text: str) -> bool:
    combined = (title + " " + text).lower()
    return any(kw in combined for kw in AI_KEYWORDS)


@retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=2, max=10))
def _fetch_page(params: dict) -> dict:
    with httpx.Client(timeout=15) as client:
        r = client.get(BASE_URL, params=params)
        r.raise_for_status()
        return r.json()


def fetch(max_results: int = 50) -> list[ToolCandidate]:
    """Return ToolCandidate objects for Show HN AI tool posts."""
    cutoff = datetime.utcnow() - timedelta(days=FRESHNESS_DAYS)
    cutoff_ts = int(cutoff.timestamp())

    params = {
        "query": "Show HN",
        "tags": "show_hn",
        "numericFilters": f"created_at_i>{cutoff_ts},points<{MAX_POINTS_FOR_OBSCURE}",
        "hitsPerPage": min(max_results, 100),
    }

    data = _fetch_page(params)
    hits = data.get("hits", [])

    candidates: list[ToolCandidate] = []
    seen_urls: set[str] = set()

    for hit in hits:
        title = hit.get("title", "")
        text = hit.get("story_text") or ""
        url = _extract_url(hit)

        if not _is_ai_related(title, text):
            continue
        if url in seen_urls:
            continue
        seen_urls.add(url)

        name = title.replace("Show HN:", "").replace("Show HN -", "").strip()
        for sep in [" – ", " - ", " (", " |"]:
            if sep in name:
                name = name.split(sep)[0].strip()

        candidates.append(
            ToolCandidate(
                name=name,
                url=url,
                source="hackernews",
                source_url=f"https://news.ycombinator.com/item?id={hit['objectID']}",
                description=text[:300].strip() if text else title,
                published_at=_parse_date(hit.get("created_at_i")),
                upvotes=hit.get("points", 0),
                comments=hit.get("num_comments", 0),
            )
        )

    return candidates
