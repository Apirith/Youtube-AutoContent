"""
connectors/github.py

Searches GitHub for freshly created AI repos with LOW stars.
A repo with 12 stars and an "ai-tools" topic is more valuable than
one with 3000 stars — that one's already discovered.

Rate limits: 10 req/min unauthenticated, 30/min with token.
"""
import httpx
from datetime import datetime, timedelta
from typing import Optional
from tenacity import retry, stop_after_attempt, wait_exponential

from toolstack.models import ToolCandidate
from toolstack.config import GITHUB_TOKEN, FRESHNESS_DAYS

SEARCH_URL = "https://api.github.com/search/repositories"

TOPICS = [
    "llm", "ai-tools", "ai-agent", "large-language-model",
    "generative-ai", "openai", "langchain", "rag", "voice-ai",
]

MAX_STARS = 100
MIN_STARS = 2


def _headers() -> dict:
    h = {"Accept": "application/vnd.github+json", "X-GitHub-Api-Version": "2022-11-28"}
    if GITHUB_TOKEN:
        h["Authorization"] = f"Bearer {GITHUB_TOKEN}"
    return h


@retry(stop=stop_after_attempt(2), wait=wait_exponential(multiplier=1, min=3, max=8))
def _search(query: str) -> list[dict]:
    params = {"q": query, "sort": "updated", "order": "desc", "per_page": 30}
    with httpx.Client(timeout=10, headers=_headers()) as client:
        r = client.get(SEARCH_URL, params=params)
        if r.status_code == 403:
            print("[github] WARN Rate limited")
            return []
        r.raise_for_status()
        return r.json().get("items", [])


def _parse_date(s: Optional[str]) -> Optional[datetime]:
    if not s:
        return None
    return datetime.strptime(s, "%Y-%m-%dT%H:%M:%SZ")


def _tool_name_from_repo(repo: dict) -> str:
    name = repo.get("name", "").replace("-", " ").replace("_", " ")
    return name.title()


def fetch(max_results: int = 60) -> list[ToolCandidate]:
    """Search GitHub for freshly created low-star AI repos."""
    cutoff = (datetime.utcnow() - timedelta(days=FRESHNESS_DAYS)).strftime("%Y-%m-%d")
    candidates: list[ToolCandidate] = []
    seen_urls: set[str] = set()

    for topic in TOPICS:
        query = (
            f"topic:{topic} "
            f"stars:{MIN_STARS}..{MAX_STARS} "
            f"pushed:>{cutoff} "
            f"fork:false"
        )
        try:
            items = _search(query)
        except Exception as e:
            print(f"[github] WARN Error on topic={topic}: {e}")
            continue

        for repo in items:
            html_url = repo.get("html_url", "")
            if not html_url or html_url in seen_urls:
                continue
            seen_urls.add(html_url)
            if repo.get("archived"):
                continue
            description = repo.get("description") or ""
            if not description:
                continue
            homepage = repo.get("homepage") or html_url
            candidates.append(
                ToolCandidate(
                    name=_tool_name_from_repo(repo),
                    url=homepage,
                    source="github",
                    source_url=html_url,
                    description=description[:300],
                    published_at=_parse_date(repo.get("created_at")),
                    stars=repo.get("stargazers_count", 0),
                )
            )

        if len(candidates) >= max_results:
            break

    return candidates[:max_results]
