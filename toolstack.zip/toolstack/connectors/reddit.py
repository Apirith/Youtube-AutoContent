"""
connectors/reddit.py

Watches subreddits where founders post their tools before they blow up.
Uses the "new" feed — hot means it's already discovered.

Subreddits:
  r/SideProject, r/indiehackers, r/MachineLearning,
  r/singularity, r/ChatGPT, r/LocalLLaMA, r/OpenAI, r/artificial
"""
import re
from datetime import datetime, timedelta
from typing import Optional

from toolstack.models import ToolCandidate
from toolstack.config import (
    REDDIT_CLIENT_ID, REDDIT_CLIENT_SECRET,
    REDDIT_USER_AGENT, FRESHNESS_DAYS,
)

SUBREDDITS = [
    "SideProject", "indiehackers", "MachineLearning",
    "singularity", "ChatGPT", "LocalLLaMA", "OpenAI", "artificial",
]

LAUNCH_SIGNALS = [
    "i built", "i made", "we built", "we launched", "launch",
    "introducing", "show hn", "just released", "open source",
    "free tool", "check out", "built a", "made a",
]

AI_KEYWORDS = [
    "ai", "llm", "gpt", "agent", "automation", "ml", "voice",
    "chatbot", "copilot", "generative", "model", "inference",
    "embedding", "rag", "multimodal", "claude", "gemini",
]

PRODUCT_URL_PATTERNS = [
    r"github\.com", r"\.ai/", r"\.io/", r"\.app/",
    r"\.dev/", r"huggingface\.co", r"replicate\.com",
]


def _is_launch_post(title: str, selftext: str) -> bool:
    combined = (title + " " + selftext[:500]).lower()
    return any(sig in combined for sig in LAUNCH_SIGNALS)


def _is_ai_related(title: str, selftext: str) -> bool:
    combined = (title + " " + selftext[:500]).lower()
    return any(kw in combined for kw in AI_KEYWORDS)


def _extract_product_url(submission) -> Optional[str]:
    if not submission.is_self:
        url = submission.url
        if any(re.search(p, url) for p in PRODUCT_URL_PATTERNS):
            return url
    urls = re.findall(r'https?://[^\s\)\]]+', submission.selftext or "")
    for url in urls:
        if any(re.search(p, url) for p in PRODUCT_URL_PATTERNS):
            return url
    return f"https://reddit.com{submission.permalink}"


def _parse_name(title: str) -> str:
    title = re.sub(
        r'^(i built|i made|we built|we launched|introducing|built a|made a)\s*:?\s*',
        '', title, flags=re.IGNORECASE
    ).strip()
    for sep in [" – ", " - ", ": ", " (", " |"]:
        if sep in title:
            return title.split(sep)[0].strip()
    words = title.split()
    return " ".join(words[:5]) if len(words) > 5 else title


def fetch(max_per_sub: int = 30) -> list[ToolCandidate]:
    """Return ToolCandidate objects from Reddit new feeds."""
    if not REDDIT_CLIENT_ID or not REDDIT_CLIENT_SECRET:
        print("[reddit] WARN No credentials — skipping Reddit connector.")
        return []

    import praw
    reddit = praw.Reddit(
        client_id=REDDIT_CLIENT_ID,
        client_secret=REDDIT_CLIENT_SECRET,
        user_agent=REDDIT_USER_AGENT,
    )

    cutoff = datetime.utcnow() - timedelta(days=FRESHNESS_DAYS)
    candidates: list[ToolCandidate] = []
    seen_urls: set[str] = set()

    for sub_name in SUBREDDITS:
        try:
            subreddit = reddit.subreddit(sub_name)
            for post in subreddit.new(limit=max_per_sub):
                created = datetime.utcfromtimestamp(post.created_utc)
                if created < cutoff:
                    continue
                title = post.title or ""
                selftext = post.selftext or ""
                if not _is_ai_related(title, selftext):
                    continue
                if not _is_launch_post(title, selftext):
                    continue
                url = _extract_product_url(post)
                if not url or url in seen_urls:
                    continue
                seen_urls.add(url)
                candidates.append(
                    ToolCandidate(
                        name=_parse_name(title),
                        url=url,
                        source="reddit",
                        source_url=f"https://reddit.com{post.permalink}",
                        description=(selftext[:300] or title).strip(),
                        published_at=created,
                        upvotes=post.score,
                        comments=post.num_comments,
                    )
                )
        except Exception as e:
            print(f"[reddit] WARN Error on r/{sub_name}: {e}")
            continue

    return candidates
