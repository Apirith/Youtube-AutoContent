"""
connectors/producthunt.py

Queries Product Hunt's GraphQL API for recently launched low-vote tools.
High vote count = already getting press = too late for us.

PH GraphQL playground: https://api.producthunt.com/v2/docs
"""
import httpx
from datetime import datetime, timedelta
from typing import Optional
from tenacity import retry, stop_after_attempt, wait_exponential

from toolstack.models import ToolCandidate
from toolstack.config import PRODUCT_HUNT_TOKEN, FRESHNESS_DAYS

GQL_URL = "https://api.producthunt.com/v2/api/graphql"
MAX_VOTES = 200

GQL_QUERY = """
query GetPosts($after: String, $postedAfter: DateTime) {
  posts(
    order: NEWEST
    after: $after
    postedAfter: $postedAfter
    topic: "artificial-intelligence"
  ) {
    edges {
      node {
        id name tagline url votesCount commentsCount createdAt website
        topics { edges { node { name } } }
      }
    }
    pageInfo { hasNextPage endCursor }
  }
}
"""


def _headers() -> dict:
    return {
        "Authorization": f"Bearer {PRODUCT_HUNT_TOKEN}",
        "Content-Type": "application/json",
        "Accept": "application/json",
    }


@retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=2, min=4, max=20))
def _gql(variables: dict) -> dict:
    with httpx.Client(timeout=20) as client:
        r = client.post(
            GQL_URL,
            json={"query": GQL_QUERY, "variables": variables},
            headers=_headers(),
        )
        r.raise_for_status()
        return r.json()


def _parse_date(s: Optional[str]) -> Optional[datetime]:
    if not s:
        return None
    try:
        return datetime.strptime(s, "%Y-%m-%dT%H:%M:%S%z").replace(tzinfo=None)
    except ValueError:
        return None


def fetch(max_results: int = 50) -> list[ToolCandidate]:
    """Return ToolCandidate objects from Product Hunt new launches."""
    if not PRODUCT_HUNT_TOKEN:
        print("[producthunt] WARN No token — skipping.")
        return []

    cutoff = (datetime.utcnow() - timedelta(days=FRESHNESS_DAYS)).strftime(
        "%Y-%m-%dT00:00:00+00:00"
    )

    candidates: list[ToolCandidate] = []
    seen_ids: set[str] = set()
    cursor: Optional[str] = None

    while len(candidates) < max_results:
        variables = {"postedAfter": cutoff}
        if cursor:
            variables["after"] = cursor

        try:
            data = _gql(variables)
        except Exception as e:
            print(f"[producthunt] WARN GraphQL error: {e}")
            break

        posts = data.get("data", {}).get("posts", {})
        edges = posts.get("edges", [])

        for edge in edges:
            node = edge.get("node", {})
            pid = node.get("id", "")
            if pid in seen_ids:
                continue
            seen_ids.add(pid)

            if node.get("votesCount", 0) > MAX_VOTES:
                continue

            topic_edges = node.get("topics", {}).get("edges", [])
            topic_names = [t["node"]["name"] for t in topic_edges]
            url = node.get("website") or node.get("url", "")
            if not url:
                continue

            description = node.get("tagline", "")
            if topic_names:
                description += f" | Topics: {', '.join(topic_names[:3])}"

            candidates.append(
                ToolCandidate(
                    name=node.get("name", "Unknown"),
                    url=url,
                    source="producthunt",
                    source_url=node.get("url", ""),
                    description=description[:300],
                    published_at=_parse_date(node.get("createdAt")),
                    upvotes=node.get("votesCount", 0),
                    comments=node.get("commentsCount", 0),
                )
            )

        page_info = posts.get("pageInfo", {})
        if not page_info.get("hasNextPage"):
            break
        cursor = page_info.get("endCursor")

    return candidates[:max_results]
