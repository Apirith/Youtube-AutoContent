"""
scoring/scorer.py

Scores candidates 0–100 on opportunity value.

Breakdown (100 pts total):
  Freshness          40 pts   Newer = first-mover advantage
  Social velocity    30 pts   Comments > upvotes as engagement signal
  Source credibility 20 pts   GitHub > HN
  Description quality 10 pts  Needs enough info to script well
"""
import math
from toolstack.models import ToolCandidate

W_FRESHNESS   = 40
W_VELOCITY    = 30
W_SOURCE      = 20
W_DESCRIPTION = 10

FRESHNESS_HALF_LIFE_HOURS = 48.0

SOURCE_SCORES = {
    "github":      1.0,
    "hackernews":  0.85,
    "producthunt": 0.75,
    "reddit":      0.60,
}


def _score_freshness(candidate: ToolCandidate) -> float:
    age_h = candidate.age_hours()
    decay = math.exp(-age_h / FRESHNESS_HALF_LIFE_HOURS)
    return round(W_FRESHNESS * decay, 2)


def _score_velocity(candidate: ToolCandidate) -> float:
    if candidate.source == "github":
        stars = candidate.stars
        if stars == 0:      return W_VELOCITY * 0.2
        elif stars < 5:     return W_VELOCITY * 0.5
        elif stars < 20:    return W_VELOCITY * 0.8
        elif stars < 50:    return W_VELOCITY * 1.0
        else:               return W_VELOCITY * 0.7

    upvotes  = max(candidate.upvotes, 1)
    comments = candidate.comments
    ratio = comments / upvotes
    ratio_factor = min(ratio / 0.3, 1.0)

    if comments >= 20:      comment_bonus = 1.0
    elif comments >= 10:    comment_bonus = 0.85
    elif comments >= 5:     comment_bonus = 0.65
    elif comments >= 2:     comment_bonus = 0.45
    else:                   comment_bonus = 0.20

    combined = (ratio_factor * 0.6 + comment_bonus * 0.4)
    return round(W_VELOCITY * combined, 2)


def _score_source(candidate: ToolCandidate) -> float:
    factor = SOURCE_SCORES.get(candidate.source, 0.5)
    return round(W_SOURCE * factor, 2)


def _score_description(candidate: ToolCandidate) -> float:
    desc = candidate.description.strip()
    if not desc:                return 0.0
    length = len(desc)
    if length >= 150:           return float(W_DESCRIPTION)
    elif length >= 80:          return W_DESCRIPTION * 0.75
    elif length >= 30:          return W_DESCRIPTION * 0.50
    else:                       return W_DESCRIPTION * 0.25


def score(candidate: ToolCandidate) -> ToolCandidate:
    """Score a single candidate. Mutates in place and returns it."""
    breakdown = {
        "freshness":   _score_freshness(candidate),
        "velocity":    _score_velocity(candidate),
        "source":      _score_source(candidate),
        "description": _score_description(candidate),
    }
    candidate.score = round(sum(breakdown.values()), 2)
    candidate.score_breakdown = breakdown
    return candidate


def score_batch(candidates: list[ToolCandidate]) -> list[ToolCandidate]:
    """Score and sort by score descending."""
    for c in candidates:
        score(c)
    return sorted(candidates, key=lambda c: c.score, reverse=True)
