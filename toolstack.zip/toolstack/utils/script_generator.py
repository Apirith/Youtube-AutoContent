"""
utils/script_generator.py

Generates a ready-to-record YouTube script saved as a Word document (.docx).

Accuracy layer:
  1. Fetches the tool's actual landing page before generating
  2. Passes raw copy to Claude as ground truth
  3. Claude flags unverifiable claims with [CHECK] — shown in orange in the doc
  4. You review [CHECK] markers before recording

Media layer:
  - Sources royalty-free images and video clips from Pexels
  - All Pexels content is free for commercial use (no attribution required)
  - Add PEXELS_API_KEY to .env to enable — free key at https://www.pexels.com/api/

Output: .docx script file + .meta.json sidecar with title/tag/thumbnail metadata
"""
import httpx
import json
import re
from datetime import datetime
from pathlib import Path
from typing import Optional

from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

from toolstack.models import ToolCandidate
from toolstack.utils.media_sourcer import source_media, download_assets

OUTPUT_DIR = Path("scripts")
OUTPUT_DIR.mkdir(exist_ok=True)

CLAUDE_API_URL = "https://api.anthropic.com/v1/messages"
CLAUDE_MODEL   = "claude-opus-4-6"

# ── Personality system prompt ─────────────────────────────────────────────────
PERSONALITY_SYSTEM_PROMPT = """
You are the scriptwriter for a YouTube channel called ToolStack that reviews
newly launched, obscure AI tools before anyone else covers them.

CHANNEL VOICE: The "Skeptical Builder"
  - You sound like a senior developer who has seen a thousand demos and
    knows which ones actually work vs. which ones are marketing fluff.
  - You are curious and fair, but you always ask: "who actually uses this?"
  - Plain English. No buzzwords unless you are calling them out.
  - Always find one genuinely impressive thing about every tool.
  - Always give an honest verdict on pricing — never hide bad news.
  - Light sarcasm is fine. Heavy negativity is not.
  - Speak in second person: "you can do X", "if you are a Y person".

SCRIPT STRUCTURE (do not change the section labels):
  [HOOK]           0–8s      Bold claim or the most surprising capability
  [CONTEXT]        8–30s     What problem was this built to solve?
  [DEMO_NARRATION] 30s–3min  Walk through actual usage, step by step
  [HONEST_TAKE]    3–4min    Who is this actually for? What is missing?
  [VERDICT]        4–4:20    One sentence summary. Score out of 10 optional.
  [CTA]            4:20–4:30 "Subscribe for more tools before they blow up."

ACCURACY RULES:
  - Facts from the landing page copy = state confidently
  - Anything you are inferring = add [CHECK] after it
  - Never invent pricing. If not in the copy, say "check their site"
  - Never say a tool "uses GPT-4" unless explicitly stated
  - Do not make comparative claims (e.g. "better than X") unless verifiable

YOUTUBE POLICY COMPLIANCE:
  - Do not make medical, legal, or financial claims
  - Do not promote illegal activity or dangerous use of the tool
  - Keep content family-friendly unless tool is clearly adult (flag with [CHECK])
  - Do not make false earnings claims or unrealistic promises

OUTPUT FORMAT:
  Script text only, with the section labels above.
  After the script, a JSON block inside ```json ``` markers containing:
    title_options: [3 YouTube title options — accurate, not clickbait]
    thumbnail_hook: Short text under 6 words for the thumbnail
    tags: [8–12 YouTube tags relevant to the tool]
    description_first_line: First line of the video description under 100 chars
    broll_search_terms: [4–6 search terms for royalty-free B-roll footage, e.g. "developer coding laptop", "AI data visualization"]
"""


def _clean(text: str) -> str:
    """Strip null bytes and control characters that break JSON payloads."""
    # Keep newline (0x0a), carriage return (0x0d), tab (0x09); remove everything else below 0x20
    return re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]', '', text)


def _fetch_landing_page(url: str) -> str:
    # Try with SSL verification first; fall back without if the CA bundle fails to load
    for verify in (True, False):
        try:
            with httpx.Client(timeout=15, follow_redirects=True, verify=verify) as client:
                r = client.get(
                    url,
                    headers={"User-Agent": "Mozilla/5.0 (compatible; ToolStack/1.0)"},
                )
                r.raise_for_status()
                text = r.text
            text = re.sub(r'<script[^>]*>.*?</script>', '', text, flags=re.DOTALL)
            text = re.sub(r'<style[^>]*>.*?</style>', '', text, flags=re.DOTALL)
            text = re.sub(r'<[^>]+>', ' ', text)
            text = re.sub(r'\s+', ' ', text).strip()
            return _clean(text[:3000])
        except (Exception, BaseException) as e:
            if isinstance(e, (KeyboardInterrupt, SystemExit)):
                raise
            if verify:
                continue  # retry without SSL verification
            print(f"[script_generator] WARN Could not fetch {url}: {type(e).__name__}")
            return ""
    return ""


def _build_user_prompt(candidate: ToolCandidate, landing_page_text: str) -> str:
    return f"""
Write a YouTube script for this AI tool:

TOOL NAME: {_clean(candidate.name)}
URL: {candidate.url}
SOURCE: {candidate.source} ({candidate.source_url})
DESCRIPTION: {_clean(candidate.description)}
SOCIAL SIGNALS: {candidate.upvotes} upvotes, {candidate.comments} comments, {candidate.stars} stars

LANDING PAGE COPY (verified source — treat as ground truth):
{landing_page_text if landing_page_text else "[Could not fetch landing page — mark any specific claims with [CHECK]]"}

Write the full script. Use [CHECK] for any claim not confirmed by the landing page copy.
""".strip()


def _add_script_section(doc: Document, label: str, content: str) -> None:
    """Add one script section with a heading and [CHECK]-highlighted body."""
    section_colors = {
        "HOOK":           RGBColor(0xC0, 0x00, 0x00),
        "CONTEXT":        RGBColor(0x1F, 0x49, 0x7D),
        "DEMO_NARRATION": RGBColor(0x37, 0x5A, 0x30),
        "HONEST_TAKE":    RGBColor(0x7B, 0x36, 0x1E),
        "VERDICT":        RGBColor(0x26, 0x26, 0x26),
        "CTA":            RGBColor(0x00, 0x70, 0xC0),
    }
    timing = {
        "HOOK":           "0 – 8 s",
        "CONTEXT":        "8 – 30 s",
        "DEMO_NARRATION": "30 s – 3 min",
        "HONEST_TAKE":    "3 – 4 min",
        "VERDICT":        "4 – 4:20",
        "CTA":            "4:20 – 4:30",
    }

    heading = doc.add_heading(level=2)
    run = heading.add_run(f"[{label}]")
    color = section_colors.get(label, RGBColor(0x26, 0x26, 0x26))
    run.font.color.rgb = color
    if label in timing:
        run2 = heading.add_run(f"  — {timing[label]}")
        run2.font.size = Pt(10)
        run2.font.color.rgb = RGBColor(0x80, 0x80, 0x80)

    paragraphs = [p.strip() for p in content.split('\n\n') if p.strip()]
    for para_text in paragraphs:
        if "[CHECK]" in para_text:
            p = doc.add_paragraph()
            segments = para_text.split("[CHECK]")
            for j, seg in enumerate(segments):
                if seg:
                    p.add_run(seg)
                if j < len(segments) - 1:
                    run = p.add_run(" [CHECK] ")
                    run.font.color.rgb = RGBColor(0xFF, 0x80, 0x00)
                    run.bold = True
        else:
            doc.add_paragraph(para_text)


def _add_table_header_row(table, headers: list[str]) -> None:
    """Bold the first row of a table and set header text."""
    row = table.rows[0]
    for i, header in enumerate(headers):
        cell = row.cells[i]
        cell.text = header
        for run in cell.paragraphs[0].runs:
            run.bold = True
        # shade header row grey
        tc = cell._tc
        tcPr = tc.get_or_add_tcPr()
        shd = OxmlElement("w:shd")
        shd.set(qn("w:val"), "clear")
        shd.set(qn("w:color"), "auto")
        shd.set(qn("w:fill"), "D9D9D9")
        tcPr.append(shd)


def _build_docx(
    candidate: ToolCandidate,
    raw_text: str,
    meta: dict,
    media: dict,
) -> Document:
    doc = Document()

    # ── Title page ───────────────────────────────────────────────────────────
    title = doc.add_heading(f"ToolStack Script: {candidate.name}", 0)
    p = doc.add_paragraph()
    p.add_run(
        f"Generated: {datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}  |  "
        f"Source: {candidate.source}  |  Score: {candidate.score:.1f} / 100"
    ).italic = True
    url_p = doc.add_paragraph()
    url_p.add_run("Tool URL: ").bold = True
    url_p.add_run(candidate.url)
    doc.add_paragraph()  # spacer

    # ── Video Metadata ────────────────────────────────────────────────────────
    doc.add_heading("Video Metadata", 1)

    doc.add_heading("Title Options", 2)
    for i, t in enumerate(meta.get("title_options", []), 1):
        doc.add_paragraph(f"{i}.  {t}", style="List Number")

    doc.add_heading("Thumbnail Hook", 2)
    p = doc.add_paragraph()
    run = p.add_run(meta.get("thumbnail_hook", ""))
    run.bold = True
    run.font.size = Pt(14)

    doc.add_heading("Tags", 2)
    doc.add_paragraph(", ".join(meta.get("tags", [])))

    doc.add_heading("Description — First Line", 2)
    doc.add_paragraph(meta.get("description_first_line", ""))

    doc.add_paragraph()  # spacer

    # ── Script ────────────────────────────────────────────────────────────────
    doc.add_heading("YouTube Script", 1)

    notice = doc.add_paragraph()
    run = notice.add_run(
        "Review every  [CHECK]  marker (shown in orange) and verify or remove "
        "each claim before recording."
    )
    run.font.color.rgb = RGBColor(0xFF, 0x80, 0x00)
    run.bold = True

    doc.add_paragraph()

    # Strip the JSON block from the bottom of the raw text
    script_only = raw_text.split("```json")[0].strip() if "```json" in raw_text else raw_text

    # Parse out named sections using known labels
    section_re = re.compile(
        r'\[(HOOK|CONTEXT|DEMO_NARRATION|HONEST_TAKE|VERDICT|CTA)\]'
    )
    parts = section_re.split(script_only)
    # parts = [preamble, LABEL, content, LABEL, content, ...]
    i = 1
    while i < len(parts) - 1:
        label   = parts[i]
        content = parts[i + 1].strip()
        _add_script_section(doc, label, content)
        doc.add_paragraph()
        i += 2

    # ── B-Roll & Media Assets ─────────────────────────────────────────────────
    doc.add_heading("Suggested B-Roll & Media Assets", 1)

    license_text = media.get(
        "license",
        "Pexels License — Free for commercial use, no attribution required. "
        "https://www.pexels.com/license/",
    )
    note = media.get("note", "")

    if note:
        p = doc.add_paragraph()
        p.add_run(note).italic = True
    else:
        doc.add_paragraph(license_text)

    images = media.get("images", [])
    videos = media.get("videos", [])

    if images:
        doc.add_heading("Photos", 2)
        table = doc.add_table(rows=1 + len(images), cols=4)
        table.style = "Table Grid"
        _add_table_header_row(table, ["Local File (images/ folder)", "Description", "Photographer", "Pexels URL"])
        for row_idx, img in enumerate(images, 1):
            cells = table.rows[row_idx].cells
            local = img.get("local_path", "")
            cells[0].text = Path(local).name if local else "(download failed)"
            cells[1].text = img.get("alt", "")
            cells[2].text = img.get("photographer", "")
            cells[3].text = img.get("url", "")
        doc.add_paragraph()

    if videos:
        doc.add_heading("Video Clips", 2)
        table = doc.add_table(rows=1 + len(videos), cols=4)
        table.style = "Table Grid"
        _add_table_header_row(table, ["Local File (videos/ folder)", "Duration", "Creator", "Pexels URL"])
        for row_idx, vid in enumerate(videos, 1):
            cells = table.rows[row_idx].cells
            local = vid.get("local_path", "")
            cells[0].text = Path(local).name if local else "(download failed)"
            cells[1].text = f"{vid.get('duration', 0)} s"
            cells[2].text = vid.get("user", "")
            cells[3].text = vid.get("url", "")
        doc.add_paragraph()

    # ── YouTube Compliance Checklist ──────────────────────────────────────────
    doc.add_heading("YouTube Compliance Checklist", 1)
    doc.add_paragraph("Complete before publishing:")

    checks = [
        "All [CHECK] markers have been verified against the tool's live website",
        "Pricing information confirmed on tool's current pricing page",
        "No copyrighted music — use YouTube Audio Library or other royalty-free source",
        "All images and clips used in the video are from the Pexels assets sourced above",
        "No third-party copyrighted footage (ads, trailers, competitor demos) without permission",
        "No medical, legal, or financial advice presented as fact",
        "If this is a sponsored or affiliate video: add a disclosure in the video and description",
        "Video title accurately represents the content — no misleading clickbait",
        "Tags are relevant to the video; no irrelevant trending-topic tags added",
        "Description includes a direct link to the tool being reviewed",
        "Thumbnail text matches the 'Thumbnail Hook' above",
        "No false earnings claims or unrealistic promises left in the final cut",
    ]

    for check in checks:
        p = doc.add_paragraph(style="List Bullet")
        p.add_run(f"☐  {check}")

    return doc


def generate_script(
    candidate: ToolCandidate,
    api_key: str,
    pexels_api_key: str = "",
) -> Optional[Path]:
    """
    Generate a script folder containing:
      script.docx         — formatted Word document
      meta.json           — YouTube metadata
      images/             — downloaded royalty-free photos
      videos/             — downloaded royalty-free video clips

    Returns path to the folder, or None on failure.
    """
    print(f"[script_generator] Fetching landing page for {candidate.name}...")
    landing_page = _fetch_landing_page(candidate.url)

    user_prompt = _build_user_prompt(candidate, landing_page)

    print(f"[script_generator] Generating script for {candidate.name}...")
    try:
        with httpx.Client(timeout=90) as client:
            r = client.post(
                CLAUDE_API_URL,
                headers={
                    "x-api-key": api_key,
                    "anthropic-version": "2023-06-01",
                    "content-type": "application/json",
                },
                json={
                    "model": CLAUDE_MODEL,
                    "max_tokens": 3000,
                    "system": PERSONALITY_SYSTEM_PROMPT,
                    "messages": [{"role": "user", "content": user_prompt}],
                },
            )
            r.raise_for_status()
            response = r.json()
    except httpx.HTTPStatusError as e:
        body = e.response.text[:300] if e.response else ""
        print(f"[script_generator] FAIL API {e.response.status_code}: {body}")
        return None
    except Exception as e:
        print(f"[script_generator] FAIL API error: {type(e).__name__}: {e}")
        return None

    raw_text = response["content"][0]["text"]

    # Parse metadata JSON
    meta: dict = {}
    json_match = re.search(r'```json\s*(.*?)```', raw_text, re.DOTALL)
    if json_match:
        try:
            meta = json.loads(json_match.group(1))
        except json.JSONDecodeError:
            print("[script_generator] WARN Could not parse metadata JSON")

    # Create per-script output folder: scripts/{timestamp}_{name}/
    safe_name  = re.sub(r'[^\w\-]', '_', candidate.name.lower())[:40]
    timestamp  = datetime.utcnow().strftime("%Y%m%d_%H%M")
    script_dir = OUTPUT_DIR / f"{timestamp}_{safe_name}"
    script_dir.mkdir(parents=True, exist_ok=True)

    # Source royalty-free media using B-roll terms from Claude
    broll_terms = meta.get("broll_search_terms", [candidate.name, "artificial intelligence technology"])
    print(f"[script_generator] Sourcing media for terms: {broll_terms[:4]}...")
    media = source_media(broll_terms, pexels_api_key)

    # Download image and video files into the folder
    if media.get("images") or media.get("videos"):
        print(f"[script_generator] Downloading {len(media['images'])} images and {len(media['videos'])} clips...")
        images, videos = download_assets(
            media["images"],
            media["videos"],
            script_dir / "images",
            script_dir / "videos",
        )
        media = {**media, "images": images, "videos": videos}

    img_count = len([i for i in media.get("images", []) if i.get("local_path")])
    vid_count = len([v for v in media.get("videos", []) if v.get("local_path")])
    print(f"[script_generator] Downloaded {img_count} images, {vid_count} clips")

    # Build and save Word document
    doc = _build_docx(candidate, raw_text, meta, media)
    script_path = script_dir / "script.docx"
    doc.save(str(script_path))
    print(f"[script_generator] OK Script saved: {script_path}")

    # Save metadata sidecar
    if meta:
        meta.update({
            "tool_name": candidate.name,
            "tool_url": candidate.url,
            "source": candidate.source,
            "score": candidate.score,
            "generated_at": datetime.utcnow().isoformat(),
            "media_images_count": img_count,
            "media_videos_count": vid_count,
        })
        meta_path = script_dir / "meta.json"
        meta_path.write_text(json.dumps(meta, indent=2), encoding="utf-8")
        print(f"[script_generator] OK Metadata saved: {meta_path}")

    return script_dir
