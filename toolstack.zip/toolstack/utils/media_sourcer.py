"""
utils/media_sourcer.py

Sources and downloads royalty-free images and video clips from Pexels.

Pexels License -- free for commercial use, no attribution required:
https://www.pexels.com/license/

Get a free API key at https://www.pexels.com/api/
"""
import re
import httpx
from pathlib import Path

PEXELS_PHOTO_URL = "https://api.pexels.com/v1/search"
PEXELS_VIDEO_URL = "https://api.pexels.com/videos/search"


def _slug(text: str) -> str:
    return re.sub(r'[^\w]', '_', text.lower())[:30].strip('_')


def _search_photos(query: str, api_key: str, per_page: int = 3) -> list[dict]:
    try:
        with httpx.Client(timeout=15) as client:
            r = client.get(
                PEXELS_PHOTO_URL,
                headers={"Authorization": api_key},
                params={"query": query, "per_page": per_page, "orientation": "landscape"},
            )
            r.raise_for_status()
            data = r.json()
        return [
            {
                "id": p["id"],
                "url": p["url"],
                "download": p["src"]["large"],
                "photographer": p["photographer"],
                "photographer_url": p["photographer_url"],
                "alt": p.get("alt", query),
                "search_term": query,
            }
            for p in data.get("photos", [])
        ]
    except Exception as e:
        print(f"[media_sourcer] WARN Photo search failed for '{query}': {e}")
        return []


def _search_videos(query: str, api_key: str, per_page: int = 3) -> list[dict]:
    try:
        with httpx.Client(timeout=15) as client:
            r = client.get(
                PEXELS_VIDEO_URL,
                headers={"Authorization": api_key},
                params={"query": query, "per_page": per_page, "orientation": "landscape"},
            )
            r.raise_for_status()
            data = r.json()
        results = []
        for v in data.get("videos", []):
            files = v.get("video_files", [])
            # Prefer SD quality (~30-60 MB) over HD (200 MB+) to keep downloads fast
            sd = [f for f in files if f.get("quality") == "sd"]
            hd = sorted(
                [f for f in files if f.get("quality") == "hd"],
                key=lambda f: f.get("width", 0),
            )
            best = sd[0] if sd else (hd[0] if hd else (files[0] if files else {}))
            results.append({
                "id": v["id"],
                "url": v["url"],
                "video_file": best.get("link", ""),
                "duration": v.get("duration", 0),
                "user": v.get("user", {}).get("name", "Unknown"),
                "user_url": v.get("user", {}).get("url", ""),
                "search_term": query,
            })
        return results
    except Exception as e:
        print(f"[media_sourcer] WARN Video search failed for '{query}': {e}")
        return []


def source_media(search_terms: list[str], api_key: str) -> dict:
    """Search Pexels for royalty-free photos and video clips."""
    if not api_key:
        return {
            "images": [],
            "videos": [],
            "note": (
                "No Pexels API key configured -- add PEXELS_API_KEY to .env "
                "to auto-source and download royalty-free images and clips. "
                "Get a free key at https://www.pexels.com/api/"
            ),
        }

    all_images: list[dict] = []
    all_videos: list[dict] = []
    seen_img_ids: set[int] = set()
    seen_vid_ids: set[int] = set()

    for term in search_terms[:4]:
        for img in _search_photos(term, api_key, per_page=3):
            if img["id"] not in seen_img_ids:
                all_images.append(img)
                seen_img_ids.add(img["id"])
        for vid in _search_videos(term, api_key, per_page=3):
            if vid["id"] not in seen_vid_ids:
                all_videos.append(vid)
                seen_vid_ids.add(vid["id"])

    return {
        "images": all_images[:10],
        "videos": all_videos[:10],
        "license": (
            "Pexels License -- Free for commercial use, no attribution required. "
            "https://www.pexels.com/license/"
        ),
    }


def download_assets(
    images: list[dict],
    videos: list[dict],
    images_dir: Path,
    videos_dir: Path,
) -> tuple[list[dict], list[dict]]:
    """
    Download image and video files to local directories.
    Adds a 'local_path' field to each asset dict.
    Returns (updated_images, updated_videos).
    """
    images_dir.mkdir(parents=True, exist_ok=True)
    videos_dir.mkdir(parents=True, exist_ok=True)

    updated_images = []
    for i, img in enumerate(images, 1):
        filename = f"{i:02d}_{_slug(img.get('search_term', 'photo'))}.jpg"
        local_path = images_dir / filename
        try:
            with httpx.Client(timeout=30, follow_redirects=True) as client:
                r = client.get(img["download"])
                r.raise_for_status()
                local_path.write_bytes(r.content)
            print(f"[media_sourcer] Downloaded image: {filename}")
            updated_images.append({**img, "local_path": str(local_path)})
        except Exception as e:
            print(f"[media_sourcer] WARN Image download failed ({filename}): {e}")
            updated_images.append({**img, "local_path": ""})

    updated_videos = []
    for i, vid in enumerate(videos, 1):
        filename = f"{i:02d}_{_slug(vid.get('search_term', 'clip'))}.mp4"
        local_path = videos_dir / filename
        video_url = vid.get("video_file", "")
        if not video_url:
            updated_videos.append({**vid, "local_path": ""})
            continue
        try:
            with httpx.Client(timeout=120, follow_redirects=True) as client:
                with client.stream("GET", video_url) as r:
                    r.raise_for_status()
                    with open(local_path, "wb") as f:
                        for chunk in r.iter_bytes(chunk_size=65536):
                            f.write(chunk)
            print(f"[media_sourcer] Downloaded video: {filename}")
            updated_videos.append({**vid, "local_path": str(local_path)})
        except Exception as e:
            print(f"[media_sourcer] WARN Video download failed ({filename}): {e}")
            updated_videos.append({**vid, "local_path": ""})

    return updated_images, updated_videos
