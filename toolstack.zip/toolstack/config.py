"""
config.py — Central config. All env vars live here.
"""
import os
from dotenv import load_dotenv

load_dotenv()

# ── Credentials ───────────────────────────────────────────────────────────────
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")
GITHUB_TOKEN      = os.getenv("GITHUB_TOKEN", "")
PEXELS_API_KEY    = os.getenv("PEXELS_API_KEY", "")

# Unused — kept as empty defaults so connectors skip gracefully
REDDIT_CLIENT_ID     = ""
REDDIT_CLIENT_SECRET = ""
REDDIT_USER_AGENT    = "toolstack-scraper/1.0"
PRODUCT_HUNT_TOKEN   = ""

# ── Pipeline thresholds ───────────────────────────────────────────────────────
FRESHNESS_DAYS      = int(os.getenv("FRESHNESS_DAYS", "7"))
MIN_SCORE_THRESHOLD = int(os.getenv("MIN_SCORE_THRESHOLD", "40"))
DB_PATH             = os.getenv("DB_PATH", "toolstack.db")
