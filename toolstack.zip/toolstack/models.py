"""
models.py — Data model for a discovered tool candidate.
Every connector returns a list of ToolCandidate objects.
"""
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional


@dataclass
class ToolCandidate:
    # ── Identity ──────────────────────────────────────────────────────────────
    name: str                          # Tool name as found in source
    url: str                           # Primary URL (landing page or repo)
    source: str                        # "hackernews" | "reddit" | "github" | "producthunt"
    source_url: str                    # Link to the original post/listing

    # ── Metadata ──────────────────────────────────────────────────────────────
    description: str = ""
    found_at: datetime = field(default_factory=datetime.utcnow)
    published_at: Optional[datetime] = None

    # ── Social signals ────────────────────────────────────────────────────────
    upvotes: int = 0
    comments: int = 0
    stars: int = 0                     # GitHub stars

    # ── Gap check results ─────────────────────────────────────────────────────
    yt_video_count: int = -1           # -1 = not checked yet
    yt_max_views: int = -1
    yt_gap_passed: Optional[bool] = None

    # ── Scoring ───────────────────────────────────────────────────────────────
    score: float = 0.0
    score_breakdown: dict = field(default_factory=dict)

    # ── Queue state ───────────────────────────────────────────────────────────
    queued: bool = False
    script_generated: bool = False
    skipped: bool = False
    skip_reason: str = ""

    def age_hours(self) -> float:
        """Hours since the source post was published."""
        if self.published_at is None:
            return 999.0
        return (datetime.utcnow() - self.published_at).total_seconds() / 3600

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "url": self.url,
            "source": self.source,
            "source_url": self.source_url,
            "description": self.description,
            "found_at": self.found_at.isoformat(),
            "published_at": self.published_at.isoformat() if self.published_at else None,
            "upvotes": self.upvotes,
            "comments": self.comments,
            "stars": self.stars,
            "yt_video_count": self.yt_video_count,
            "yt_max_views": self.yt_max_views,
            "yt_gap_passed": self.yt_gap_passed,
            "score": self.score,
            "score_breakdown": self.score_breakdown,
            "queued": self.queued,
            "script_generated": self.script_generated,
            "skipped": self.skipped,
            "skip_reason": self.skip_reason,
        }
