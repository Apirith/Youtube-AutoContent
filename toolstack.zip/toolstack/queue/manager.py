"""
queue/manager.py

SQLite queue for tool candidates.

Tables:
  candidates   — All tools seen, with full metadata + state
  run_log      — Log of each pipeline run
"""
import json
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Optional

from toolstack.models import ToolCandidate
from toolstack.config import DB_PATH, MIN_SCORE_THRESHOLD

SCHEMA = """
CREATE TABLE IF NOT EXISTS candidates (
    url               TEXT PRIMARY KEY,
    name              TEXT NOT NULL,
    source            TEXT NOT NULL,
    source_url        TEXT,
    description       TEXT,
    found_at          TEXT,
    published_at      TEXT,
    upvotes           INTEGER DEFAULT 0,
    comments          INTEGER DEFAULT 0,
    stars             INTEGER DEFAULT 0,
    yt_video_count    INTEGER DEFAULT -1,
    yt_max_views      INTEGER DEFAULT -1,
    yt_gap_passed     INTEGER,
    score             REAL DEFAULT 0,
    score_breakdown   TEXT,
    queued            INTEGER DEFAULT 0,
    script_generated  INTEGER DEFAULT 0,
    skipped           INTEGER DEFAULT 0,
    skip_reason       TEXT DEFAULT ''
);

CREATE TABLE IF NOT EXISTS run_log (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    ran_at        TEXT NOT NULL,
    found         INTEGER DEFAULT 0,
    gap_checked   INTEGER DEFAULT 0,
    queued        INTEGER DEFAULT 0,
    skipped       INTEGER DEFAULT 0,
    notes         TEXT
);

CREATE INDEX IF NOT EXISTS idx_score   ON candidates(score DESC);
CREATE INDEX IF NOT EXISTS idx_queued  ON candidates(queued, script_generated);
CREATE INDEX IF NOT EXISTS idx_source  ON candidates(source);
"""


def _conn() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with _conn() as conn:
        conn.executescript(SCHEMA)
    print(f"[queue] Database ready at {Path(DB_PATH).resolve()}")


def upsert(candidate: ToolCandidate):
    d = candidate.to_dict()
    with _conn() as conn:
        conn.execute("""
            INSERT INTO candidates (
                url, name, source, source_url, description,
                found_at, published_at, upvotes, comments, stars,
                yt_video_count, yt_max_views, yt_gap_passed,
                score, score_breakdown, queued, script_generated,
                skipped, skip_reason
            ) VALUES (
                :url, :name, :source, :source_url, :description,
                :found_at, :published_at, :upvotes, :comments, :stars,
                :yt_video_count, :yt_max_views, :yt_gap_passed,
                :score, :score_breakdown, :queued, :script_generated,
                :skipped, :skip_reason
            )
            ON CONFLICT(url) DO UPDATE SET
                score           = excluded.score,
                score_breakdown = excluded.score_breakdown,
                yt_video_count  = excluded.yt_video_count,
                yt_max_views    = excluded.yt_max_views,
                yt_gap_passed   = excluded.yt_gap_passed
        """, {
            **d,
            "yt_gap_passed": (
                None if d["yt_gap_passed"] is None else int(d["yt_gap_passed"])
            ),
            "score_breakdown": json.dumps(d["score_breakdown"]),
        })


def mark_queued(url: str):
    with _conn() as conn:
        conn.execute("UPDATE candidates SET queued=1 WHERE url=?", (url,))


def mark_script_generated(url: str):
    with _conn() as conn:
        conn.execute("UPDATE candidates SET script_generated=1 WHERE url=?", (url,))


def mark_skipped(url: str, reason: str):
    with _conn() as conn:
        conn.execute(
            "UPDATE candidates SET skipped=1, skip_reason=? WHERE url=?",
            (reason, url),
        )


def log_run(found: int, gap_checked: int, queued: int, skipped: int, notes: str = ""):
    with _conn() as conn:
        conn.execute(
            "INSERT INTO run_log (ran_at, found, gap_checked, queued, skipped, notes) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (datetime.utcnow().isoformat(), found, gap_checked, queued, skipped, notes),
        )


def already_seen(url: str) -> bool:
    with _conn() as conn:
        row = conn.execute("SELECT 1 FROM candidates WHERE url=?", (url,)).fetchone()
    return row is not None


def get_queue(limit: int = 20) -> list[dict]:
    with _conn() as conn:
        rows = conn.execute("""
            SELECT * FROM candidates
            WHERE queued=1 AND script_generated=0 AND skipped=0
            ORDER BY score DESC LIMIT ?
        """, (limit,)).fetchall()
    return [dict(r) for r in rows]


def get_stats() -> dict:
    with _conn() as conn:
        total    = conn.execute("SELECT COUNT(*) FROM candidates").fetchone()[0]
        queued   = conn.execute("SELECT COUNT(*) FROM candidates WHERE queued=1").fetchone()[0]
        scripted = conn.execute("SELECT COUNT(*) FROM candidates WHERE script_generated=1").fetchone()[0]
        skipped  = conn.execute("SELECT COUNT(*) FROM candidates WHERE skipped=1").fetchone()[0]
        runs     = conn.execute("SELECT COUNT(*) FROM run_log").fetchone()[0]
    return {
        "total_seen": total, "queued": queued,
        "scripted": scripted, "skipped": skipped, "pipeline_runs": runs,
    }


def get_ready_for_queue(min_score: float = MIN_SCORE_THRESHOLD, limit: int = 10) -> list[dict]:
    with _conn() as conn:
        rows = conn.execute("""
            SELECT * FROM candidates
            WHERE yt_gap_passed=1 AND score >= ? AND queued=0 AND skipped=0
            ORDER BY score DESC LIMIT ?
        """, (min_score, limit)).fetchall()
    return [dict(r) for r in rows]
