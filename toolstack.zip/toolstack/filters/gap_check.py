"""
filters/gap_check.py

No YouTube API configured — all candidates pass through automatically.
"""
from toolstack.models import ToolCandidate


def check(candidate: ToolCandidate) -> ToolCandidate:
    candidate.yt_video_count = 0
    candidate.yt_max_views = 0
    candidate.yt_gap_passed = True
    return candidate


def check_batch(
    candidates: list[ToolCandidate],
    skip_already_checked: bool = True,
) -> list[ToolCandidate]:
    for c in candidates:
        if skip_already_checked and c.yt_gap_passed is not None:
            continue
        check(c)
    return candidates
